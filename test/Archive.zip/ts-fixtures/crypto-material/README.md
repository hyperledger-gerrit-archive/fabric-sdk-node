All crypto material here is generated via the contained shell scripts files and orchestrated by the parent gulp files `/build/tasks/certs.js`, please use the gulp files to create any required certificates by:
- Obtain crypto-gen binaries (`gulp get-crypto-binaries`)
- Generate the crypto material required for tests (`gulp generate-test-certs`)
